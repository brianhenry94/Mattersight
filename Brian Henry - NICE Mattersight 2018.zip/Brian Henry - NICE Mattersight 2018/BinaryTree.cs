﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BrianHenry_BinaryTreeChallenge
{
    public class BinaryTree
    {
        public BinaryTree() { }
        public BinaryTree(int value)
        {
            NodeValue = value;
        }

        public BinaryTree Left;
        public BinaryTree Right;
        public int NodeValue;

        public BinaryTree Insert(BinaryTree node, int value)
        {
            if (node == null)
            {
                node = new BinaryTree(value);
                return node;
            }

            if (value < node.NodeValue)
            {

                node.Left = Insert(node.Left, value);
                node.Left.stepCounter++;
            }
            else if (value > node.NodeValue)
            {

                node.Right = Insert(node.Right, value);
                node.Right.stepCounter++;
            }

            return node;
        }

        public int[][] ValuesWithSteps;
        public int stepCounter = 0;
        public BinaryTree Find(BinaryTree root, int value)
        {
            if (root == null || root.NodeValue == value)
            {
                return root;
            }

            if (value < root.NodeValue)
            {
                return Find(root.Left, value);
            }
            else
            {
                return Find(root.Right, value);
            }
        }

    }
}
