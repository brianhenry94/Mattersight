﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//This class was heavily inspired by user Ivan Stoev's answer at https://stackoverflow.com/questions/36311991/c-sharp-display-a-binary-search-tree-in-console and contains some refactorings of said answer.
namespace BrianHenry_BinaryTreeChallenge
{
    public static class BinaryTreePrinter
    {
        class PrinterNode
        {
            public BinaryTree Node;
            public string Text;
            public int StartPosition;
            public int Size => Text.Length;
            public int EndPosition { get => StartPosition + Size; set { StartPosition = value - Size; } }
            public PrinterNode Parent, Left, Right;
        }

        public static void Print(this BinaryTree root, int marginTop = 2, int marginLeft = 2)
        {
            Console.Write("Brian Henry - Binary Tree Programming Challenge for Mattersight 2018\n");
            Console.WriteLine("The tree will be randomly generated with 10 integers from 1-19");
            if (root == null) return;
            int rootTop = Console.CursorTop + marginTop;
            var totalLines = new List<PrinterNode>();
            var nextNode = root;

            for (int lineNumber = 0; nextNode != null; lineNumber++)
            {
                var currentNode = new PrinterNode { Node = nextNode, Text = $"  {nextNode.NodeValue}  " };
                if (lineNumber < totalLines.Count)
                {
                    currentNode.StartPosition = totalLines[lineNumber].EndPosition + 1;
                    totalLines[lineNumber] = currentNode;
                }
                else
                {
                    currentNode.StartPosition = marginLeft;
                    totalLines.Add(currentNode);
                }
                if (lineNumber > 0)
                {
                    currentNode.Parent = totalLines[lineNumber - 1];
                    if (nextNode == currentNode.Parent.Node.Left)
                    {
                        currentNode.Parent.Left = currentNode;
                        currentNode.EndPosition = Math.Max(currentNode.EndPosition, currentNode.Parent.StartPosition);
                    }
                    else
                    {
                        currentNode.Parent.Right = currentNode;
                        currentNode.StartPosition = Math.Max(currentNode.StartPosition, currentNode.Parent.EndPosition);
                    }
                }
                nextNode = nextNode.Left ?? nextNode.Right;
                for (; nextNode == null; currentNode = currentNode.Parent)
                {
                    Print(currentNode, rootTop + 2 * lineNumber);
                    if (--lineNumber < 0) break;
                    if (currentNode == currentNode.Parent.Left)
                    {
                        currentNode.Parent.StartPosition = currentNode.EndPosition;
                        nextNode = currentNode.Parent.Node.Right;
                    }
                    else
                    {
                        if (currentNode.Parent.Left == null)
                            currentNode.Parent.EndPosition = currentNode.StartPosition;
                        else
                            currentNode.Parent.StartPosition += (currentNode.StartPosition - currentNode.Parent.EndPosition) / 2;
                    }
                }
            }
            Console.SetCursorPosition(0, rootTop + 2 * totalLines.Count - 2);
            Console.Write("\n\nChallenge: Find the ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("nearest");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.Write(" common ancestor of two values.");
        }

        private static void Print(PrinterNode node, int top)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            SwapColors();
            Print(node.Text, top, node.StartPosition);
            SwapColors();
            if (node.Left != null)
                PrintLink(top + 1, "┌", "┘", node.Left.StartPosition + node.Left.Size / 2, node.StartPosition);
            if (node.Right != null)
                PrintLink(top + 1, "└", "┐", node.EndPosition - 1, node.Right.StartPosition + node.Right.Size / 2);
            Console.ForegroundColor = ConsoleColor.Gray;
        }

        private static void PrintLink(int cursorTop, string cursorStart, string end, int startPosition, int endPosition)
        {
            Print(cursorStart, cursorTop, startPosition);
            Print("─", cursorTop, startPosition + 1, endPosition);
            Print(end, cursorTop, endPosition);
        }

        private static void Print(string stringToPrint, int top, int cursorLeft, int cursorRight = -1)
        {
            Console.SetCursorPosition(cursorLeft, top);
            if (cursorRight < 0) cursorRight = cursorLeft + stringToPrint.Length;
            while (Console.CursorLeft < cursorRight) Console.Write(stringToPrint);
        }

        private static void SwapColors()
        {
            var color = Console.ForegroundColor;
            Console.ForegroundColor = Console.BackgroundColor;
            Console.BackgroundColor = color;
        }
    }
}
