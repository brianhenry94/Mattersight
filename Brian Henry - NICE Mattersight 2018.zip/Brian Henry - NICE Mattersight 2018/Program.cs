﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Brian Henry 
//(360) 440-4825
//2018
namespace BrianHenry_BinaryTreeChallenge
{
    class Program
    {
        private List<int> _path1;
        private List<int> _path2;

        static void Main(string[] args)
        {
            StartProgram();
        }

        private static void StartProgram()
        {
            var root = new BinaryTree(20);

            var random = new Random();

            for (int i = 0; i < 11; i++)
            {
                root.Insert(root, random.Next(1, 19));
            }

            root.Print();

            PromptUserForInput(root);
        }

        private static void PromptUserForInput(BinaryTree root)
        {
            var validInput = false;
            int firstValue = 0;
            int secondValue = 0;
            while (!validInput)
            {
                Console.WriteLine("\nEnter first integer value: ");
                var input = Console.ReadLine();
                if (int.TryParse(input, out firstValue) && (0 < firstValue && firstValue < 21))
                {
                    break;
                }
                Console.WriteLine("Enter a valid integer value from 1-20.");
            }

            while (!validInput)
            {
                Console.WriteLine("Enter second integer value: ");
                var input = Console.ReadLine();
                if (int.TryParse(input, out secondValue) && (0 < secondValue && secondValue < 21))
                {
                    break;
                }
                Console.WriteLine("Enter a valid integer value from 1-20.");
            }

            Console.WriteLine("Closest node: " + FindCommonAncestor(root, firstValue, secondValue));
            Console.WriteLine("Try a new set of integers (this will create a new tree!)? Y/N");

            while (!validInput)
            {
                var answer = Console.ReadLine();

                if (answer.Equals("y", StringComparison.OrdinalIgnoreCase))
                {
                    validInput = true;
                    Console.Clear();
                    StartProgram();
                }
                else if (answer.Equals("n", StringComparison.OrdinalIgnoreCase))
                {
                    validInput = true;
                    Environment.Exit(0);
                }
            }
        }

        private static BinaryTree _closestAncestor;
        private static int FindCommonAncestor(BinaryTree root, int val1, int val2)
        {
            _closestAncestor = root; // if we wanted the LOWEST common ancestor, we'd omit this statement

            if (val1 < root.NodeValue && val2 < root.NodeValue) //if both values are less than current node, traverse left
            {
                root = root.Left;
                FindCommonAncestor(root, val1, val2);
            }
            else if (val1 > root.NodeValue && val2 > root.NodeValue) //if both values are greater than current node, traverse right
            {
                root = root.Right;
                FindCommonAncestor(root, val1, val2);
            }

            return _closestAncestor.NodeValue;
        }
    }
}


